/* #undef AUTH_MODE_CERT */
#define AUTH_MODE_KEY
/* #undef AUTH_WITH_NOTLS */
#define GATEWAY_ENABLED
/* #undef COAP_COMM_ENABLED */
#define OTA_MQTT_CHANNEL
/* #undef SYSTEM_COMM */
#define EVENT_POST_ENABLED
#define ACTION_ENABLED
#define DEV_DYN_REG_ENABLED
/* #undef LOG_UPLOAD */
/* #undef IOT_DEBUG */
#define DEBUG_DEV_INFO_USED
/* #undef AT_TCP_ENABLED */
/* #undef AT_UART_RECV_IRQ */
/* #undef AT_OS_USED */
/* #undef AT_DEBUG */
//#define OTA_USE_HTTPS
#define MULTITHREAD_ENABLED
